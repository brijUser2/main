﻿using System;
using System.Runtime.InteropServices.JavaScript;
using System.Threading.Tasks;
using Trivedi;

Console.WriteLine("Hello, Browser!");

public partial class MyClass
{

    static byte[] tmpBuffer = new byte[2048];

    [JSExport]
    internal static string Greeting()
    {
        var text = $"Hello, World! Greetings from {GetHRef()}";
        Console.WriteLine("Console writeline in Greeting methd: " + text);
        var strL = (Trivedi.Core.stat(text,"x")).ToString();

//        var deS = (Core.deSerToList("")).ToString();

        return (text + "<hr><br><b>(from fs Core invocation):</b>" + strL);
    }


    [JSExport]
    internal static byte[] reqB(string param)
    {
        return Trivedi.gfx.reqB(param);
    }

    internal static async void GetUrlBytes(string p) {
        tmpBuffer = (Trivedi.gfx.reqUrl(p));
/*
        Task.Run((p) =>
                {
            tmpBuffer = (Trivedi.gfx.reqUrl(p));
                });
*/
    }

    [JSExport]
    internal static byte[] reqUrl(string param)
    {
        Console.WriteLine("reqUrl 1: b4 call");
        GetUrlBytes(param);
        Console.WriteLine("reqUrl 1: after call");        
        return tmpBuffer;
    }

    [JSImport("window.location.href", "main.js")]
    internal static partial string GetHRef();
}