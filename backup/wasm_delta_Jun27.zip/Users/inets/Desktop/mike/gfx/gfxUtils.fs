﻿(*  gfx (TM)
    Copyright (c) M. P. Trivedi 2016-2024.  All rights reserved.
    TrivediBldHdr->
    |Trivedi SrcCtrlHdr File.  Copyright (c) 2015-2024 M. P. Trivedi.  All rights reserved.|637901455|gfxUtils.fs|none|- - - - - - ->* louisa * St.Francis * PIUTE * princeedward * SALTLAKE * Jefferson * craven * <* Obion * CERROGORDO * fayette * LEFLORE * Suffolk * elmore * SweetGrass * <* BLAND * pittsburg * VANDERBURGH * Pittsburg * california * Coffee * PETROLEUM * <* westcarrollparish * ANTRIM * Titus * fortbend * Audrain * STANLEY * losangeles * <* LINCOLNPARISH * PointeCoupeeParish * lee * Nuckolls * CONECUH * hotspring * EDWARDS * <|- - - - - - ->* louisa * St.Francis * PIUTE * princeedward * SALTLAKE * Jefferson * craven * <* Obion * CERROGORDO * fayette * LEFLORE * Suffolk * elmore * SweetGrass * <* BLAND * pittsburg * VANDERBURGH * Pittsburg * california * Coffee * PETROLEUM * <* westcarrollparish * ANTRIM * Titus * fortbend * Audrain * STANLEY * losangeles * <* LINCOLNPARISH * PointeCoupeeParish * lee * Nuckolls * CONECUH * hotspring * EDWARDS * <|
*)

namespace Trivedi

[<AutoOpen>]
module gfxUtils =
    open System
    open System.IO
    open Trivedi.Core
    open System.Resources

    let addResources = 
        printfn "(gfxUtils) now Adding Resources in gfx.fs..."
        use resx = new ResXResourceWriter(@".\GfxResources.resx")
        resx.AddResource("gfxLogo", (File.ReadAllBytes("C:\Users\inets\Desktop\mike\gfx\Getafix.png")));

    let chkResources = 
        printfn "(gfxUtils) now Checking Resources in gfx.fs..."
        let resSet = new ResXResourceSet(@".\GfxResources.resx");
        let dict = resSet.GetEnumerator()
        while (dict.MoveNext()) do
             let key = (string) dict.Key
             match (dict.Value) with
             | :? string as s ->
                    printfn "Key: %A: Val: %A" key (resSet.GetString(key))
             | _ -> 
                    printfn "Key: %A: Val: %A" key  (resSet.GetObject(key))
        printfn "chkResources done..."

    printfn "eom"