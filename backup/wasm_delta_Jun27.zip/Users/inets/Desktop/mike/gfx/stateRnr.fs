﻿module stateRunner = 
    open System
(*  See the foll. 2 Ruby importers (both MIT lic.), 
    seem to be the most comprehensive:
    (i)  https://github.com/pcreux/csv-importer
    (ii) https://github.com/tilo/smarter_csv
See also the canonical def (with gotchas) for the CSV fmt @ 
https://en.wikipedia.org/wiki/Comma-separated_values#Example *)


    type StErrH = | ApplicativeStyle
                  | MonadicStyle
    type StRun = | StRun of {| st: string; stg: int; res: Boolean; errH: StErrH |}

    let today = DateTime.Now
    let dow = DateTime.Now.DayOfWeek
    let tmpInp = {1..12} |> List.ofSeq 

    let rndChk() =
        let r = Random().Next(1,11)
        match r > 5 with
        | true -> true
        | _ -> false

    let runProc =
        fun (s:StRun) -> 
            printfn "running Proc..."
            let (StRun(sInnr)) = s
            let tmp = {| sInnr with res = rndChk() |}
            {| tmp with stg = sInnr.stg + 1 |}

    let initSt = StRun({| st="st"; stg=0;res=false; errH=ApplicativeStyle |})

    //runProc 
    let escTrim = 
        fun h ->
            let trimd = h.Trim()
            let fstChr = (trimd).Substring(0,1)
            let lstChr = (trimd).Substring(trimd.Length -1)
            match (fstChr = lstChr) with
            | true ->
                match ((fstChr = "\"") || (fstChr = "'")) with
                | true -> trimd.Substring(1,trimd.Length -1)
                | _ ->  trimd
            | _ -> trimd
            
    let hasHdr =
        fun hLine sep ->
            let c = (સપ્લીટ hLine sep)
            match (( c |> len) > 1) with
            | true -> 
                (true,c) |> lifo (fun s f -> 
                            let h1 = escTrim f
                            match ((tryParseInt f) || (tryParseFloat f) || (tryParseSingle f) || (tryParseDouble f) || (tryParseDateTime f)) with
                            | true -> (false, f)
                            | _ -> (true, f)) |> fst
            | _ -> false

    let getRowSep =
        fun strFl ->
            //All poss line-endings are '\r', '\n', '\r\n' & '\f' (frmFeed)
            let lineEndingTy = 
                if strFl.contains("\r\n") then "\r\n"
                    elseIf strFl.contains("\r\n") then "\f"
                        elseIf strFl.contains("\r") then "\r"
                            else "\n"
            let c = (સપ્લીટ strFl lineEndingTy)
            let hasRecs = if (len c) > 1 then true else false
            (lineEndingTy, hasRecs)
    
    let getFldSep =
        fun strHdr ->
            //Header and records lines must use the same field delimiters
            (["\t";",";";";"|"], (false, None))
            |> lim (fun s sep -> 
                        let (fnd, opt) = s 
                        match opt.IsNone with
                        | true -> 
                            match(સપ્લીટ strFl lineEndingTy).Length > 1 with
                            | true -> ((true, Some(sep), sep))
                            | _ -> (s, sep)
                        | _ -> (s, sep) )

(*
    hasHdr -> if no, prompt >> 
        getRowSep -> if no recs, prompt >> 
            getFldSep -> if fldLen < 2, prompt >>
                runImport [[runProc]] -> 
                    errs? yes ->  prompt w/ListOfErrs (allow print/save) >>
                          no ->   () >>
                        showSampleRecs for validityChk >>
                            Continue Parial/Full? 
                                yes -> import 
                                no -> abort

    Result<t> in F# 8 now has:
    (Error 2, 0) ||> Result.foldBack (fun x accum -> accum + x * 2) // evaluates to 0
    (Ok 1, 0) ||> Result.foldBack (fun x accum -> accum + x * 2) // evaluates to 2
    (Ok 1, 10) ||> Result.foldBack (fun x accum -> accum + x * 2) // evaluates to 12
*)
    printfn "Hello World! %A" dow