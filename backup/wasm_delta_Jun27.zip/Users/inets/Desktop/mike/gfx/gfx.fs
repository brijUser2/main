﻿(*  gfx (TM)
    Copyright (c) M. P. Trivedi 2016-2024.  All rights reserved.
    TrivediBldHdr->
    |Trivedi SrcCtrlHdr File.  Copyright (c) 2015-2024 M. P. Trivedi.  All rights reserved.|637901455|test.fs|none|- - - - - - ->* louisa * St.Francis * PIUTE * princeedward * SALTLAKE * Jefferson * craven * <* Obion * CERROGORDO * fayette * LEFLORE * Suffolk * elmore * SweetGrass * <* BLAND * pittsburg * VANDERBURGH * Pittsburg * california * Coffee * PETROLEUM * <* westcarrollparish * ANTRIM * Titus * fortbend * Audrain * STANLEY * losangeles * <* LINCOLNPARISH * PointeCoupeeParish * lee * Nuckolls * CONECUH * hotspring * EDWARDS * <|- - - - - - ->* louisa * St.Francis * PIUTE * princeedward * SALTLAKE * Jefferson * craven * <* Obion * CERROGORDO * fayette * LEFLORE * Suffolk * elmore * SweetGrass * <* BLAND * pittsburg * VANDERBURGH * Pittsburg * california * Coffee * PETROLEUM * <* westcarrollparish * ANTRIM * Titus * fortbend * Audrain * STANLEY * losangeles * <* LINCOLNPARISH * PointeCoupeeParish * lee * Nuckolls * CONECUH * hotspring * EDWARDS * <|
*)

namespace Trivedi

//see alt type/bld @ https://github.com/TrivediEnterprisesInc/TrivediEnterprisesInc.github.io/blob/main/ui/2024/menu/ModelBuilder.fs

//to avoid confusion for the tree ren tags to 'path', rem list
type TreeModelItm = | TreeModelItm of unid:int * divId:string * title:string * tags:string list * parent:string * layer:string with
    member this.toString() = 
        let (TreeModelItm(u,d,t,tg,p,l)) = this
        "Unid: " + u.ToString() + " divId: " + d + " Title: " + t + " Tags: " + tg.ToString() + " ParentId: " + p + " Layer: " + l
    member this.toWobblyString() = 
        let (TreeModelItm(u,d,t,tg,c,l)) =   this
        """{ Unid:"{u.ToString()}", divId: "{d}", Title:"{t}" Tags:"{tg.ToString()}"  ParentId:"{p}" Layer:{l}"""

type TreeDataItm = | TreeDataItm of unid:string * divId:string * title:string * tags:string list * content:string * notes:string with
    member this.toString() = 
        let (TreeDataItm(u,d,t,tg,c,n)) = this
        "Unid: " + u + " divId: " + d + " Title: " + t + " Tags: " + tg.ToString() + " Content len: " + (c.Length).ToString() + " Notes: " + n

[<AutoOpen>]
module wwwHelpers =
    open System

    //@HardCoded @ToDo: repoint to usrCurrVal after config hooks are in place
    let TitlePnTolerence = 9
    let getTitlePane =
        fun dId tit opn cont ->
            """<div id={dId} data-dojo-type="dijit/TitlePane" data-dojo-props="title: {tit}, open:{opn}">
                  {cont}
               </div>
            """
    let getMBox = 
        fun dId tit opn ->
            """
                tbfo
            """

    let getSingleDiv = 
        fun dId tit cont ->
            """<div id={dId}>
                  {cont}
               </div>
            """
    let wrapInDiv = 
        fun txt ->
            """<div>
                   {txt}
               </div>"""


[<AutoOpen>]
module gfx =
    open System
    open System.IO
    open Trivedi.Core
//    open System.Windows.Forms //for resx
    open System.Resources
    open System.Net.Http

#if tbfo
    let mShowTxtDiv =
        fun divId ->
            let allMatches = dat |> List.filter(fun itm -> itmHasTags divId)
            match (allMatches.length <= TitlePnTolerence) with
            | true when (allMatches.length = 1) ->
                allMatches |> List.head |> getSingleDiv dId tit cont
            | true when (allMatches.length > 1) ->
                allMatches |> lifo(fun s v -> 
                                        discombob
                                        s + "<br>\n" + getTitlePane dId tit opn cont)
            | _ -> 
                allMatches |> lifo(fun s v -> 
                                        discombob
                                        s + "<br>\n" + getMBox dId tit opn cont)
#endif

(*
            if (strId == "misc_www_dojo_jsonp") {
              	getDojoPulls();
            } else if (strId == "filmMain") {
		...
            } else if (strId == "changeLog") {
		... manual blds (cld feed or gen) 
            calls fetchHtmlAsText brijLog23...
          } else if (strId == "devFS") {
		let titles = ["Links", "Core", "Combinators", "Editors", "Compiler", "Snippets", "Freeware", "Reading", "Crypto", "UI"];
	        (titles.map(function (tVal, idx) {....
		...
            } else if (strId == "db") {
		let titles = ["mongo", "other"];
	        (titles.map(function (tVal, idx) {
		...
            } else if (strId == "devMisc") {
		let titles = ["dojo", "www_Links", "www_dojo_links", "www_dojo_jsonp", "www_other","www_console","domino","crypto", "java_funct", "java_hotSwap", "java_spxDesign", "java_nlp"];
	        (titles.map(function (tVal, idx) {
		...
            } else if (strId == "film") {
		...
            } else {
              	curDivId = dom.byId(strId);
	        var newTxt = (curDivId.innerHTML);
		mainDiv.innerHTML = newTxt;
*)


    let dat = [TreeModelItm(1,"root","Root",[],"","base");
                TreeModelItm(10,"dev","dev",["career"], "career","layer2");
                TreeModelItm(5,"devFS","F#/.net",["career";"dev"], "dev","layer3");
                TreeModelItm(52,"gearpers","personal",["gear"], "gear","layer2");
                TreeModelItm(11,"sartorial","sartorial",["gear";"gearpers"], "gearpers","layer2");
                TreeModelItm(14,"planning","acc.",["gear";"gearpers"], "gearpers","layer2");
                TreeModelItm(12,"audio","audio/ht",["gear"], "gear","layer2");
                TreeModelItm(13,"furniture","furniture",["gear"], "gear","layer2");
                TreeModelItm(15,"film","film",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(16,"food","food",["body"], "body","layer2");
                TreeModelItm(51,"exercise","exercise",["body"], "body","layer2");
                TreeModelItm(17,"NYCeat","NYC Eating Out",["body";"food"], "food","layer3");
                TreeModelItm(53,"miscFood","food misc",["body";"food"], "food","layer3");
                TreeModelItm(18,"re","real estate",["gear"], "gear","layer3");
                TreeModelItm(19,"NYCStorage","storage",["gear"], "gear","layer2");
                TreeModelItm(20,"NYCdesi","Desi Stuff",["mind";"mindAmuse";"social"], "social","layer2");
                TreeModelItm(33,"db","db",["career";"dev"], "dev","layer3");
                TreeModelItm(39,"corp","corp",["career";"dev"], "dev","layer3");
                TreeModelItm(350,"devAPI","currentAPI",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm(351,"flowcharts","flowcharts",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm(352,"changeLog","log",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm(353,"eagleEye","eagleEye",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm(37,"career","work",[],"","layer1");
                TreeModelItm(34,"mind","mind",[],"","layer1");
                TreeModelItm(35,"body","body",[],"","layer1");
                TreeModelItm(36,"gear","gear",[],"","layer1");
                TreeModelItm(46,"music","music",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(38,"social","social",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(339,"devNotes","notes",["career"], "career","layer2");
                TreeModelItm(50,"miscJob","jobs",["career"], "career","layer2");
                TreeModelItm(90,"fin","finance",["career"], "career","layer2");
                TreeModelItm(44,"mindAmuse","amuse",["mind"], "mind","layer2");
                TreeModelItm(40,"mindInstr","instruct",["mind"], "mind","layer2");
                TreeModelItm(45,"elevate","elevate",["mind"], "mind","layer2");
                TreeModelItm(270,"elevateLinks","elevateLinks",["mind";"elevate"], "elevate","layer3");
                TreeModelItm(271,"buddhism","buddhism",["mind";"elevate"], "elevate","layer3");
                TreeModelItm(21,"lrnlang","languages",["mind";"mindInstr"], "mindInstr","layer3");
                TreeModelItm(41,"lrnFrench","french",["mind";"mindInstr";"lrnlang"], "lrnlang","layer4");
                TreeModelItm(42,"lrnUrdu","urdu",["mind";"mindInstr";"lrnlang"], "lrnlang","layer4");
                TreeModelItm(43,"lrnGujarati","gujarati",["mind";"mindInstr";"lrnlang"], "lrnlang","layer4");
                TreeModelItm(48,"artLit","art/lit",["mind";"mindInstr"], "mindInstr","layer3");
                TreeModelItm(49,"edOther","other",["mind";"mindInstr"], "mindInstr","layer3");
                TreeModelItm(47,"miscReading","reading",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(50,"amusetravel","travel",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(51,"travelNYC","nyc",["mind";"mindAmuse";"amusetravel"], "amusetravel","layer4");
                TreeModelItm(96,"tv","tv",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(399,"devMisc","misc",["career";"dev"], "dev","layer3");
                TreeModelItm(118,"recM2S","m2s",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(119,"recOther","other",["mind";"mindAmuse"], "mindAmuse","layer3")]

    let prnDat = dat |> List.mapi (fun i x -> printfn "%A) %A" i (x.toString())) |> ignore
    //let getTreeOb = fun dat -> List.fold (fun s v -> s + "\n" + v.toWobblyString() + ",\n") "" dat
            
    let genDjConfig() = 
        fun dat ->
            let hdr = """
    var djConfig = {
      isDebug: true, 
      popup:true, 
      parseOnLoad: true, 
      useCustomLogger:true,
      mData : [
"""
            let ftr = """
],
      debugPrintStr : "dojoConfig"
    };
"""
            let newCfg = hdr //+ (getTreeOb dat) + ftr
            File.WriteAllText("djconfig.js", newCfg) //overwrite
            
    let reqS = 
        fun (p:string) ->
            "return call From Gfx.dll for reqS with param: " + p
            
    let reqB =
        fun (p:string) ->
            printfn "currDir is: %A" ((Directory.GetFiles("/") |> List.ofArray).ToString())
            match p with
            | "img" -> 
                let resSet = new ResourceSet(@".\GfxResources.resx")
                printfn "reqB: returning resSet.getObj..."
                resSet.GetObject("gfxLogo") :?> byte[]
            | _ -> 
                    બાઇટ ("return call From Gfx.dll for reqB with param: " + p)

    let countImg = """
iVBORw0KGgoAAAANSUhEUgAAAF0AAAA4CAYAAACfSPQqAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAXTSURBVHhe7ZvdbxRVGIf9Q0QJslCoRVs0IkpMiVGCH8GYgPbCDwJeSBBDQlSMJkSL0ZgYNNGlViPGeOEFCV4YUdvENGINUpE23dIUjLK1u13wXxjP75w5s+fMvDM7H2d2ZtK5eDKdmTNfz77znvfMTG86eXnZKukupfQMKKVnQCk9A0rpGVBKz4BSegbkVvovR45ZtUd3W7O7hjhnPxgl2xWRXEo//8Jh68bNazV+O/AK2baI5E46JbyUniJ+wkEpPQWChINSumG++/hLUrTKxNF3yG2LSC6kTz/5DBNbsW6sqliNSp9HOCgj3SBnT3wmxDLhmC5s36nJlnRLOkpVWaYGkaSEzVT6p9N1q7H+Tkf4P1sGrZ/feNcjHKSZXqTov7Y+SB6bYmFwZ2zxmUr/6b1PnIuoD9zHl/lJP3f4Tc/2Jpjd9TR5vDDEvfsylT73yG5xAbess05N1vgyRLT74ur9Wz3bmuDqtoc8x4pC4aRDMj95llomD73uLKciXaSWpt0G06ZVdebjUe+/13OcqBRO+sWh/ezEK1ZrzUb2A8yyZUImJX3yJfGjVOcE+r6iy1/aOODsu9EzYNUe3+MLcrd6LiqFks4HQnbnOfX8QUcm8KSXW9fzu8ItXJ2vzoUX37RL0musD7m0Zy/ZRuXMqdO+4gsj3SkRARP6xa9toWCG1+ztC/vj2ReddXIfansxH076Ug+rlNjd1diwmVzvh1/nXgjpKBEX++4RJ23nclUgNTLFhUm5QG0vl4eRLiKcpbPVPeT6IAotfWz4I3HCTDhyuYxyrBuZpyuXiaPHne3dwuW2cuqHjHBUSdT6ThRW+sglfSA0tfcgW84iVInSideGAy8MFYtXestZT7F4R/vOotaHwU963LFDV6RDzthbJ9onbHeOahs+Ou3p1y4KaCNR9gPpwoPBmyfs479V8SJcQklPMnZIXzqTMzrjzeXuduroVEW7hSNIl4+KkwoHlPS4qQV0IdKb1vhxPZe7oxyEypuKdHVbN06HbEA4KIx0dIwQjij35nJve6oTBbr0cGmlsW6TMeGgQJHe5OLHh4NzuSRMpKM05NL5D0qzuOluo8KBe+wAkjyAS0W6iEYR5Z1yucQv0n/f97LTBvsdmfevVuqsUrkesyz0gxo7JH0AZ1y6TCuYuutyvygHfpEOsB+0CRL+95ZB1rYSeIw4mE4twLx0VjdDeNhcLgmSzi8yIJfP73iCtat0PEYcci+9WsNU5vIPnZNcvq3X+vzCFU97lSDpQW9pIJqPNgP6iyQUINKF8NGZRS2Xn/nqW6KtTpB0oOZ2ifO0kpFGlAOqE82H9HkM5YVw5F21Lp9+qvPjUzAmtwkAbWR77YV2SlHu92lIPqTb1QqEay+bI8pANFMXKZFpRjsG48K+Q+T+kuJ392UvnUc5m9oPrsbftutyJiPqLd8pxQBcsHqMa5vvJ/dlAr/zSfqSPLF0dYSIqF5eezuXEabzdBP0lkay8MAOvm9+jEofuR9TUNKX2B1GtY2CgfTSfjR7ddvDXAYI03mqyB+vU26/bk/jvIyICiU9aWoBZnI644f3T4oTY8L/HNpPtvEDwsVoU8x3yu3oK9z7SINcS1c7tqhDZClcXRaYZrokHCxsf8xz/NxIVzs2+blEGHTh7TQFqChrrenV2qRJWuUiSCwdnWdr9QaRy6OUiKzqcUe4ijva/+29i2yXFn6VSy6kI51w4YxzR46RbSiqtVagdADx+OAnzPcppvGTbuKbykTSp547wE5ECJ+KMEBxnos7y/TUkgco6abuttjS26/Eogpv53ExDX6bnxVu6U0D9bkktvSJV8XnElGEq3m8Pc1flANVuknhIJZ0+aVWJOHAFqxHez6ly3LRtHAQS/rXP57nTxKpdZ2QwvMsXabOtJ7rJOpIo6IKz7P00998HzuowtA96XY+L4L0tOmedCaXkr4SyUy6XJ7031iKSCbSMe+Wv5LounT87RG+ovL6svU/ustAKK15CUcAAAAASUVORK5CYII="""

    let reqBase =
        fun (p:string) ->
            printfn "1. gfx.fs: inside reqBase ..."
            let res = b64Dec countImg
            printfn "reqBase sending Getafix len = %A" (res.Length)
            res

    let reqUrl =
        fun (p:string) ->
            printfn "1. gfx.fs: inside reqUrl ..."
            let client = new System.Net.Http.HttpClient()
            let  resp = ref (new HttpResponseMessage())
            //printfn "1. gfx.fs: inside reqUrl ..."
            async {
                printfn "1. gfx.fs: inside reqUrl ..."
                let! resp2 = client.GetAsync(Uri("https://raw.githubusercontent.com/TrivediEnterprisesInc/TrivediEnterprisesInc.github.io/main/img/Hulk.png")) |> Async.AwaitTask
                resp.Value <- resp2
            }  |> Async.RunSynchronously
            printfn "1. gfx.fs: inside reqUrl ..."
            let bA = (resp.Value).Content.ReadAsByteArrayAsync().Result
            bA
            
            (*
//            tk.Result //gets result of Task
            //} |> Async.RunSynchronously
            |> Async.StartAsTask
            
            let client = new HttpClient()
            //Async<byte array>
            //let res =
            printfn "2. gfx.fs: invoking async CE ..."
            async{
                client.GetAsync(Uri("https://raw.githubusercontent.com/TrivediEnterprisesInc/TrivediEnterprisesInc.github.io/main/img/Hulk.png")) 
                } 
            |> Async.RunSynchronously
    //printfn "3. gfx.fs:reqUrl sending Hulk len = %A" (res.length)
    //res
    *)
    
(*
C:\Users\inets\Desktop\mike\packs\NETStandard.Library.Ref\2.1.0\ref\netstandard2.1 gives a CancellationToken err

   using: C:\Users\inets\desktop\mike\packs\Microsoft.NETCore.App.Ref\8.0.2\ref\net8.0 for Sys.Runtime
    //C:\Users\inets\Desktop\mike\gfx\gfx.fs(201,24): error FS0039: 
    //The field, constructor or member 'AsyncDownloadData' is not defined.
//Microsoft (R) F# Compiler version 10.2.3 for F# 4.5
*)
    printfn "gfx.fs.eom"

    let addResources() = 
        printfn "now Adding Resources in gfx.fs..."
        use resx = new ResourceWriter(@".\GfxResources.resx")
        resx.AddResource("gfxLogo", (File.ReadAllBytes("Users\inets\Desktop\mike\gfx\Getafix.png")));

    printfn "eom"
