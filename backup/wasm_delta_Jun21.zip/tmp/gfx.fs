﻿namespace Trivedi

//see alt type/bld @ https://github.com/TrivediEnterprisesInc/TrivediEnterprisesInc.github.io/blob/main/ui/2024/menu/ModelBuilder.fs

//to avoid confusion for the tree ren tags to 'path', rem list
type TreeModelItm = | TreeModelItm of unid:int * divId:string * title:string * tags:string list * parent:string * layer:string with
    member this.toString() = 
        let (TreeModelItm(u,d,t,tg,p,l)) = this
        "Unid: " + u.ToString() + " divId: " + d + " Title: " + t + " Tags: " + tg.ToString() + " ParentId: " + p + " Layer: " + l
    member this.toWobblyString() = 
        let (TreeModelItm(u,d,t,tg,c,l)) =   this
        """{ Unid:"{u.ToString()}", divId: "{d}", Title:"{t}" Tags:"{tg.ToString()}"  ParentId:"{p}" Layer:{l}"""

type TreeDataItm = | TreeDataItm of unid:string * divId:string * title:string * tags:string list * content:string * notes:string with
    member this.toString() = 
        let (TreeDataItm(u,d,t,tg,c,n)) = this
        "Unid: " + u + " divId: " + d + " Title: " + t + " Tags: " + tg.ToString() + " Content len: " + (c.Length).ToString() + " Notes: " + n

[<AutoOpen>]
module wwwHelpers =
    open System

    //@HardCoded @ToDo: repoint to usrCurrVal after config hooks are in place
    let TitlePnTolerence = 9
    let getTitlePane =
        fun dId tit opn cont ->
            """<div id={dId} data-dojo-type="dijit/TitlePane" data-dojo-props="title: {tit}, open:{opn}">
                  {cont}
               </div>
            """
    let getMBox = 
        fun dId tit opn ->
            """
                tbfo
            """

    let getSingleDiv = 
        fun dId tit cont ->
            """<div id={dId}>
                  {cont}
               </div>
            """
    let wrapInDiv = 
        fun txt ->
            """<div>
                   {txt}
               </div>"""


[<AutoOpen>]
module gfx =
    open System
    open System.IO
    open Trivedi.Core

#if tbfo
    let mShowTxtDiv =
        fun divId ->
            let allMatches = dat |> List.filter(fun itm -> itmHasTags divId)
            match (allMatches.length <= TitlePnTolerence) with
            | true when (allMatches.length = 1) ->
                allMatches |> List.head |> getSingleDiv dId tit cont
            | true when (allMatches.length > 1) ->
                allMatches |> lifo(fun s v -> 
                                        discombob
                                        s + "<br>\n" + getTitlePane dId tit opn cont)
            | _ -> 
                allMatches |> lifo(fun s v -> 
                                        discombob
                                        s + "<br>\n" + getMBox dId tit opn cont)
#endif

(*
            if (strId == "misc_www_dojo_jsonp") {
              	getDojoPulls();
            } else if (strId == "filmMain") {
		...
            } else if (strId == "changeLog") {
		... manual blds (cld feed or gen) 
            calls fetchHtmlAsText brijLog23...
          } else if (strId == "devFS") {
		let titles = ["Links", "Core", "Combinators", "Editors", "Compiler", "Snippets", "Freeware", "Reading", "Crypto", "UI"];
	        (titles.map(function (tVal, idx) {....
		...
            } else if (strId == "db") {
		let titles = ["mongo", "other"];
	        (titles.map(function (tVal, idx) {
		...
            } else if (strId == "devMisc") {
		let titles = ["dojo", "www_Links", "www_dojo_links", "www_dojo_jsonp", "www_other","www_console","domino","crypto", "java_funct", "java_hotSwap", "java_spxDesign", "java_nlp"];
	        (titles.map(function (tVal, idx) {
		...
            } else if (strId == "film") {
		...
            } else {
              	curDivId = dom.byId(strId);
	        var newTxt = (curDivId.innerHTML);
		mainDiv.innerHTML = newTxt;
*)


    let dat = [TreeModelItm(1,"root","Root",[],"","base");
                TreeModelItm(10,"dev","dev",["career"], "career","layer2");
                TreeModelItm(5,"devFS","F#/.net",["career";"dev"], "dev","layer3");
                TreeModelItm(52,"gearpers","personal",["gear"], "gear","layer2");
                TreeModelItm(11,"sartorial","sartorial",["gear";"gearpers"], "gearpers","layer2");
                TreeModelItm(14,"planning","acc.",["gear";"gearpers"], "gearpers","layer2");
                TreeModelItm(12,"audio","audio/ht",["gear"], "gear","layer2");
                TreeModelItm(13,"furniture","furniture",["gear"], "gear","layer2");
                TreeModelItm(15,"film","film",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(16,"food","food",["body"], "body","layer2");
                TreeModelItm(51,"exercise","exercise",["body"], "body","layer2");
                TreeModelItm(17,"NYCeat","NYC Eating Out",["body";"food"], "food","layer3");
                TreeModelItm(53,"miscFood","food misc",["body";"food"], "food","layer3");
                TreeModelItm(18,"re","real estate",["gear"], "gear","layer3");
                TreeModelItm(19,"NYCStorage","storage",["gear"], "gear","layer2");
                TreeModelItm(20,"NYCdesi","Desi Stuff",["mind";"mindAmuse";"social"], "social","layer2");
                TreeModelItm(33,"db","db",["career";"dev"], "dev","layer3");
                TreeModelItm(39,"corp","corp",["career";"dev"], "dev","layer3");
                TreeModelItm(350,"devAPI","currentAPI",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm(351,"flowcharts","flowcharts",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm(352,"changeLog","log",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm(353,"eagleEye","eagleEye",["career";"dev";"corp"], "corp","layer4");
                TreeModelItm(37,"career","work",[],"","layer1");
                TreeModelItm(34,"mind","mind",[],"","layer1");
                TreeModelItm(35,"body","body",[],"","layer1");
                TreeModelItm(36,"gear","gear",[],"","layer1");
                TreeModelItm(46,"music","music",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(38,"social","social",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(339,"devNotes","notes",["career"], "career","layer2");
                TreeModelItm(50,"miscJob","jobs",["career"], "career","layer2");
                TreeModelItm(90,"fin","finance",["career"], "career","layer2");
                TreeModelItm(44,"mindAmuse","amuse",["mind"], "mind","layer2");
                TreeModelItm(40,"mindInstr","instruct",["mind"], "mind","layer2");
                TreeModelItm(45,"elevate","elevate",["mind"], "mind","layer2");
                TreeModelItm(270,"elevateLinks","elevateLinks",["mind";"elevate"], "elevate","layer3");
                TreeModelItm(271,"buddhism","buddhism",["mind";"elevate"], "elevate","layer3");
                TreeModelItm(21,"lrnlang","languages",["mind";"mindInstr"], "mindInstr","layer3");
                TreeModelItm(41,"lrnFrench","french",["mind";"mindInstr";"lrnlang"], "lrnlang","layer4");
                TreeModelItm(42,"lrnUrdu","urdu",["mind";"mindInstr";"lrnlang"], "lrnlang","layer4");
                TreeModelItm(43,"lrnGujarati","gujarati",["mind";"mindInstr";"lrnlang"], "lrnlang","layer4");
                TreeModelItm(48,"artLit","art/lit",["mind";"mindInstr"], "mindInstr","layer3");
                TreeModelItm(49,"edOther","other",["mind";"mindInstr"], "mindInstr","layer3");
                TreeModelItm(47,"miscReading","reading",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(50,"amusetravel","travel",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(51,"travelNYC","nyc",["mind";"mindAmuse";"amusetravel"], "amusetravel","layer4");
                TreeModelItm(96,"tv","tv",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(399,"devMisc","misc",["career";"dev"], "dev","layer3");
                TreeModelItm(118,"recM2S","m2s",["mind";"mindAmuse"], "mindAmuse","layer3");
                TreeModelItm(119,"recOther","other",["mind";"mindAmuse"], "mindAmuse","layer3")]

    let prnDat = dat |> List.mapi (fun i x -> printfn "%A) %A" i (x.toString())) |> ignore
    //let getTreeOb = fun dat -> List.fold (fun s v -> s + "\n" + v.toWobblyString() + ",\n") "" dat
            
    let genDjConfig() = 
        fun dat ->
            let hdr = """
    var djConfig = {
      isDebug: true, 
      popup:true, 
      parseOnLoad: true, 
      useCustomLogger:true,
      mData : [
"""
            let ftr = """
],
      debugPrintStr : "dojoConfig"
    };
"""
            let newCfg = hdr //+ (getTreeOb dat) + ftr
            File.WriteAllText("djconfig.js", newCfg) //overwrite
            
    let reqS = 
        fun (p:string) ->
            "return call From Gfx.dll for reqS with param: " + p
            
    let reqB =
        fun (p:string) ->
            printfn "currDir is: %A" ((Directory.GetFiles("/") |> List.ofArray).ToString())
            match p with
            | "img" -> 
                match File.Exists("Getafix.png") with
                | true -> File.ReadAllBytes("Getafix.png")
                | _ -> 
                    printfn ("File not found: Getafix.png")
                    [] |> Array.ofList
            | _ -> 
                    બાઇટ ("return call From Gfx.dll for reqB with param: " + p)
                

    printfn "eom"
