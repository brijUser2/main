﻿using System;
using System.Runtime.InteropServices.JavaScript;
using Trivedi;

Console.WriteLine("Hello, Browser!");

public partial class MyClass
{
    [JSExport]
    internal static string Greeting()
    {
        var text = $"Hello, World! Greetings from {GetHRef()}";
        Console.WriteLine("Console writeline in Greeting methd: " + text);
        var strL = (Trivedi.Core.stat(text,"x")).ToString();

//        var deS = (Core.deSerToList("")).ToString();

        return (text + "<hr><br><b>(from fs Core invocation):</b>" + strL);
    }

    [JSExport]
    internal static string reqS(string param)
    {
        return Trivedi.gfx.reqS(param);
    }

    [JSExport]
    internal static byte[] reqB(string param)
    {
        return Trivedi.gfx.reqB(param);
    }
   
    [JSImport("window.location.href", "main.js")]
    internal static partial string GetHRef();
}
